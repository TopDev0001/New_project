<div style="position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #333333;
    color: white;
    text-align: center;">
    <p style="margin: 10px 0px 10px 0px;">© Copyright Ego Pharmaceuticals. All Rights Reserved 2022.</p>
</div>