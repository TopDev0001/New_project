<?php
session_start();
include('includes/config.php');
error_reporting(0);

?>

<!DOCTYPE HTML>
<html lang="en">

<head>

    <title> QV Mini Game </title>
    <!--Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="img/style.css">

</head>

<body>
    <!-- Banners -->
    <section id="banner" class="banner-section1">
        <div class="container" style=" width: 100%;">
            <div class="col-md-12 " style="padding-top: 120px;">
                <div class="col-md-1 ">
                </div>

                <div class="col-md-5 ">
                </div>
                <div class="col-md-6" style="text-align: center;">


                    <h4 style="color: #293D8A;">Kulitnya menjadi kering kerana berada di dalam <br>bilik berhawa dingin
                        sepanjang hari.</h4>
                    <h2 style="color:#293D8A"> Raya Ini, Pilih Kebaikan!</h2>
                    <h3 style="color:#293D8A">Pilih <img src="img/logo.png" style="height: 30px; margin:2px"> Cream
                        untuk membantu kulitnya <br> agar terasa segar, lembut dan lembap </h3>
                    <br>
                    <div class="col-md-3 " style="padding-left: 20px;">
                        <img src="img/tube.png">
                    </div>
                    <div class="col-md-2 ">
                        <img src="img/icon1.png" style="height:40px; width:40px; margin:3px">
                        <img src="img/icon2.png" style="height:55px; width:55px; margin:3px">
                        <img src="img/icon3.png">
                    </div>
                    <div style="padding: 60px 0px 0px 0px;">
                        <div class="col-md-1 ">
                            <img src="img/finger.png" style="height: 50px;">
                        </div>
                        <div class="col-md-4 ">
                            <h6 style="color:#293D8A"> DRAG & DROP QV Cream ke atas kulit MUKA dan TANGAN nya.
                            </h6>
                        </div>
                    </div>
                </div>


            </div>
        </div>

        <div class="popup">
            <h2>Congratulations</h2>
            <p>You are the winner, Please fill Your Details and Win Prize</p>
            <a href="pop.php"> <button class="btn btn-primary">Okay, Next</button> </a>

        </div>

        <script src="img/script.js"></script>
        <br><br><br><br><br><br><br>
    </section>





    <!-- Scripts -->

    <script src="assets/js/bootstrap.min.js"></script>




</body>

</html>